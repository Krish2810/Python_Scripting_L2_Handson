# 1. It is in a separate folder.

# 2. Write a program to handle the following exceptions

#Keyboardinterrupt
try:
    inp = input()
    print ("Press Ctrl+C or Interrupt the Kernel.")
except KeyboardInterrupt:
    print("Caught KeyboardInterrupt")
else:
    print ('No exception occurred!')
finally:
    print("Always run this block!")
    
#NameError
try:
    print (ans)
except NameError:  
    print ("NameError: name 'ans' is not defined")
else:  
    print ("Success, no error!")
finally:
    print("Always run this block!")

#ArithmeticError
try:  
    a = 100 / 0
    print (a)
except ZeroDivisionError:  
        print ("Zero Division Exception Raised." )
else:  
    print ("Success, no error!")
finally:
    print("Always run this block!")
    
    
# 3.How do you handle exception for the following code? 

c = 0 
try:
    def f2(x):    
        c+= 1    
        b = x + c     
        print (c)    
        return b 

    print(f2(1))
    print(c)
except NameError as ne:
    print("OOPS!", ne.__class__, "occured")
    
"""# 4.  Translate each of the following English statements into a regular expression: 
    a. digit at the beginning of the string and a digit at the end of the string 
    b. A string that contains only whitespace characters or word characters 
    c. A string containing no whitespace characters """
    
    
"""
 5.Write a program using re module that loops through the lines of a file or standard input (where each line contains a single word) 
 and prints all words containing two adjacent vowels 
"""   

import re
def main():
    file = './file1'
    f = open(file,'r')
    print(re.findall("[A-Za-z]*"+ "[AEIOUaeiou]"*2 + "[A-Za-z]*",f.read()))
    f.close()

main()


"""
 6. Implement a child class called mathnew and parent classes as sqroot, addition, subtraction, multiplication and division.
 Use the super () function to inherit the parent methods. 
"""

import math

class sqroot(object):
    def __init__(self,a,b):
        c = (math.sqrt(a))
        print(c)

class addition(object):
    def __init__(a,b):
        c = a+b
        print(c)

class substraction(object):
    def __init__(a,b):
        c = a - b
        print(c)

class multiplication(object):
    def __init__(a,b):
        c = a * b
        print(c)

class division(object):
    def __init__(a,b):
        c = a/b
        print(c)

class mathnew(sqroot,addition,substraction,multiplication,division):
    def __init__(self):
        print("results are")
        super().__init__(4,2)
        addition.__init__(2,3)
        substraction.__init__(1,6)
        multiplication.__init__(6,2)
        division.__init__(5,1)
    
d1 = mathnew()



"""
7. Create a class called First and two classes called Second and Third which inherit from First. 
Create class called Fourth which inherits from Second and Third.
Create a common method called method1 in all the classes and provide the Method Resolution Order
"""
class First:
    def method1(self):
        print("I am a First class")

class Second(First):
    def method1(self):
        print("I am a Second class")

class Third(First):
    def method1(self):
        print("I am a Third class")

class Fourth(Second,Third):
    def method1(self):
        print("I am a Fourth class")

d1= Fourth()
d1.method1()



# 8.Implement a simple generator for Fibonacci serie

a = int(input('Give amount: '))

def fib(n):
    a, b = 0, 1
    for _ in range(n):
        yield a
        a, b = b, a + b

print(list(fib(a)))



# 9.Write an iterator class that iterators over a sequence of values in the reverse direction 

class reverse_iterator:
     def __init__(self, collection):
         self.data = collection
         self.index = len(self.data)
     def __iter__(self):
         return self
     def next(self):
         if self.index == 0:
             raise StopIteration
         self.index = self.index - 1
         return self.data[self.index]
     
it = reversed(['a', 1, 2, 3, 'c', 17])
type(it)

for each in it:
    print (each)



# 10. Implement a decorator that quantifies and returns the execution time of any function 

from functools import wraps
from time import time


def timing(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        start = time()
        result = f(*args, **kwargs)
        end = time()
        print ('Elapsed time: {}'.format(end-start))
        return result
    return wrapper

@timing
def f(a):
    for _ in range(a):
        pass

print(f(2000000))




