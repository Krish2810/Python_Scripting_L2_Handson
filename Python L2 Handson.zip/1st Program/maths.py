from calc import factorial, trignometry

factorial(4)

