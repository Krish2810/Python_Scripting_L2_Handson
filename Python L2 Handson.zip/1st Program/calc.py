#function to find the factorial of a number 
def factorial(num):
    n=num
    factorial = 1
    if int(n) >= 1:
        for i in range (1,int(n)+1):
            factorial = factorial * i
        print("Factorail of ",n , " is : ",factorial)
            
factorial(4)

#function to find the log10 of a number 
import math as m
def log(num):
    logg =m.log10(num)
    print(logg)
    
log(100.12)
     
#function to convert degrees to radians
def degreetoradian(degre):
    float(degre)
    pi=22/7
    radian = degre*(pi/180)
    print(radian)
    
degreetoradian(90.2)

#The sin, cos and tan trigonometric functions
import math as m
def trignometry(val):
    print("Value of sin: ",m.sin(val))
    print("Value of cos: ",m.cos(val))
    print("Value of tan: ",m.tan(val))
    
trignometry(5)
